<?php  
 
 $link = mysqli_connect("localhost", "mysql", "mysql", "medikusman");  
 $output = '';  
 $order = $_POST["order"];  
 if($order == 'desc')  
 {  
      $order = 'asc';  
 }  
 else  
 {  
      $order = 'desc';  
 }  
 $query = "SELECT * FROM users ORDER BY ".$_POST["column_name"]." ".$_POST["order"]."";  
 $result1 = mysqli_query($link, $query);  
 $output .= '  
 <table class="table table-bordered">  
      <tr>  
           <th><a class="column_sort" id="id" data-order="'.$order.'" href="#">Ид-тор</a></th>  
           <th><a class="column_sort" id="name" data-order="'.$order.'" href="#">Имя</a></th>  
           <th><a class="column_sort" id="surname" data-order="'.$order.'" href="#">Фамилия</a></th>  
           <th><a class="column_sort" id="login" data-order="'.$order.'" href="#">Логин</a></th>  
           <th><a class="column_sort" id="email" data-order="'.$order.'" href="#">Почта</a></th>  
           <th><a class="column_sort" id="gender" data-order="'.$order.'" href="#">Пол</a></th>  
           <th><a class="column_sort" id="dateborn" data-order="'.$order.'" href="#">Дата рождения</a></th>  
           <th><a class="column_sort" id="password" data-order="'.$order.'" href="#">Пароль</a></th>  
      </tr>  
 ';  
 while($row = mysqli_fetch_array($result1))  
 {  
      $output .= '  
      <tr>  
           <td>' . $row["id"] . '</td>  
           <td>' . $row["name"] . '</td>  
           <td>' . $row["surname"] . '</td>  
           <td>' . $row["login"] . '</td>  
           <td>' . $row["email"] . '</td>  
           <td>' . $row["gender"] . '</td>  
           <td>' . $row["dateborn"] . '</td>  
           <td>' . $row["password"] . '</td>  
      </tr>  
      ';  
 }  
 $output .= '</table>';  
 echo $output;  
 ?>