<?php

require 'libs/rb.php';
R::setup('mysql:host=localhost;dbname=medikusman',
	'mysql','mysql');

session_start();


