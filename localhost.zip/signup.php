<?php
	require "db.php";
	
	$data = $_POST;
	if (isset($data['do_signup']))
		//print_r($data);
	{
		//Здесь регистрируем пользователя
		$errors = array();
		if( trim($data['name']) == "")
		{
			$errors[] = 'Введите имя!';
		}
		if( trim($data['surname']) == "")
		{
			$errors[] = 'Введите фамилию!';
		}
		if( trim($data['login']) == "")
		{
			$errors[] = 'Введите логин!';
		}
		if( trim($data['email']) == "")
		{
			$errors[] = 'Введите email!';
		}
		if( trim($data['gender']) == "")
		{
			$errors[] = 'Введите ваш пол!';
		}
		if( trim($data['dateborn']) == "")
		{
			$errors[] = 'Введите дату рождения!';
		}
		if( trim($data['password']) == "")
		{
			$errors[] = 'Введите пароль!';
		}
		if( trim($data['password_2'] != $data['password']))
		{
			$errors[] = 'Пароли не совпадают!';
		}
		//считаем есть ли такой логин
		if( R::count('users', "login = ? OR email = ?", array(  
		$data['login'], $data['login'])) > 0 ) 
		{
			$errors[] = 'Пользователь с таким логином - ' .$data['login']. ' существует!';
		}
		//считаем есть ли такой почтой
		if( R::count('users', "email = ? OR email = ?", array( 
		$data['login'], $data['email'])) > 0 ) 
		{
			$errors[] = 'Пользователь с таким email - ' .$data['email']. ' существует!';
		}
		if( empty($errors))
		{	
			// Все хорошо, регистрируем пользователя
			$user = R::dispense('users');
			$user->name = $data['name'];
			$user->surname = $data['surname'];
			$user->login = $data['login'];
			$user->email = $data['email'];
			$user->gender = $data['gender'];
			$user->dateborn = $data['dateborn'];
			$user->password = password_hash($data['password'], PASSWORD_DEFAULT);
			R::store($user);
			echo '<div style="color: green;">'.$user['login'].' вы успешно зарегистрированы!</div><hr><p>
    <a href="/logout.php">Выйти</a>
    </p>';
		}	else
		{
			echo '<div style="color: red;">'.array_shift($errors).'</div><hr>';
		}
	
	}

	//$data = trim($data);
?>

<a href="/" style="text-decoration: none;">На главную</a>

<form action="/signup.php" method="POST">
	
		<p><strong>Ваше имя</strong>:</p>
		<input type="text" name="name" value="<?php echo @$data['name']; ?> ">
	
		<p><strong>Ваша фамилия</strong>:</p>
		<input type="text" name="surname" value="<?php echo @$data['surname']; ?> ">

		<p><strong>Ваш логин</strong>:</p>
		<input type="text" name="login" value="<?php echo @$data['login']; ?> ">
	
		<p><strong>Ваш Email</strong>:</p>
		<input type="email" name="email" value="<?php echo @$data['email']; ?> ">

		<p><strong>Ваш пол</strong>:</p>
		<input type="text" name="gender" value="<?php echo @$data['gender']; ?> ">
		
		<p><strong>Дата рождения</strong>:</p>
		<input type="date" name="dateborn" value="<?php echo @$data['dateborn']; ?> ">
	
		<p><strong>Ваш пароль</strong>:</p>
		<input type="password" name="password" value="<?php echo @$data['password']; ?> ">

		<p><strong>Подтвердить пароль</strong>:</p>
		<input type="password" name="password_2" value="<?php echo @$data['password_2']; ?> ">
	
	
	
		<button type="submit" name="do_signup">Зарегистрироваться</button>
	
	
</form>