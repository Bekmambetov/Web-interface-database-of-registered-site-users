<?php
    require "db.php";
?>

<?php if( isset($_SESSION['logged_user']) ) : ?>
    <b style="color: green;">Авторизован!</b><br/><p>
    Привет <?php //var_dump($_SESSION['logged_user']);
    echo $_SESSION['logged_user']->login; ?>!</p>
    <p>
    <a href="/logout.php">Выйти</a>
    </p>
 <html>  
      <head>  
           <title>Meder Bekmambetov</title>  
           <script src="jquery.min.js"></script>  
           <link rel="stylesheet" href="bootstrap.min.css" />
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" /> 
			<link rel="stylesheet" href="style.css" />
           <script src="bootstrap.min.js"></script>  
      </head>  
      <body>

<?php
    $host = 'localhost';  // Хост, у нас все локально
    $user = 'mysql';    // Имя созданного вами пользователя
    $pass = 'mysql'; // Установленный вами пароль пользователю
    $db_login = 'medikusman';   // Имя базы данных
    $link = mysqli_connect($host, $user, $pass, $db_login); // Соединяемся с базой

     // Ругаемся, если соединение установить не удалось
    if (!$link) {
      echo 'Не могу соединиться с БД. Код ошибки: ' . mysqli_connect_errno() . ', ошибка: ' . mysqli_connect_error();
      exit;
    }

    //Если переменные формы переданы, то 
    if (isset($_POST["login"])) {
      //Если это запрос на изменение, то изменяем данные из формы
      if (isset($_GET['red'])) {
        $sql = mysqli_query($link, "UPDATE `users` SET `name` = '{$_POST['name']}', `surname` = '{$_POST['surname']}', `login` = '{$_POST['login']}', `email` = '{$_POST['email']}', `gender` = '{$_POST['gender']}', `dateborn` = '{$_POST['dateborn']}', `password` = '{$_POST['password']}' WHERE `ID`={$_GET['red']}");

      } else {
        //Иначе вставляем данные, подставляя их в запрос
        $sql = mysqli_query($link, "INSERT INTO `users` (`name`, `surname`, `login`, `email`, `gender`, `dateborn`, `password`) VALUES ('{$_POST['name']}', '{$_POST['surname']}', '{$_POST['login']}', '{$_POST['email']}', '{$_POST['gender']}', '{$_POST['dateborn']}', '{$_POST['password']}')");
    }

      //Если вставка прошла успешно, выводим
      if ($sql) {
        echo '<p>Успешно!</p>';
      } else {
        echo '<p>Произошла ошибка: ' . mysqli_error($link) . '</p>';
      }
    }

    //Удаляем запись при нажантии '?del={$result['ID']}' и выводим
    if (isset($_GET['del'])) {
      $sql = mysqli_query($link, "DELETE FROM `users` WHERE `ID` = {$_GET['del']}");
      if ($sql) {
        echo "<p>Запись удалена.</p>";
      } else {
        echo '<p>Произошла ошибка: ' . mysqli_error($link) . '</p>';
      }
    }

    //Если передана переменная red, prsm то надо изменить данные. Для начала достанем их из БД
    if (isset($_GET['red'])) {
      $sql = mysqli_query($link, "SELECT `ID`, `name`, `surname`, `login`, `email`, `gender`, `dateborn`, `password` FROM `users` WHERE `ID`={$_GET['red']}");
      $product = mysqli_fetch_array($sql);
    }
    if (isset($_GET['prsm'])) {
      $sql = mysqli_query($link, "SELECT `ID`, `name`, `surname`, `login`, `email`, `gender`, `dateborn`, `password` FROM `users` WHERE `ID`={$_GET['prsm']}");
      $product = mysqli_fetch_array($sql);
    }

  ?>

  <form action="" method="post">
  <b>Просмотр</b>
    <table>
      <tr>
        <tr>
        <td>Имя:</td>
        <td><input type="text" name="name" value="<?= isset($_GET['prsm']) ? $product['name'] : ''; ?>"></td>
        <td>Фамилия:</td>
        <td><input type="text" name="surname" value="<?= isset($_GET['prsm']) ? $product['surname'] : ''; ?>"></td>
        <td>Логин:</td>
        <td><input type="text" name="login" value="<?= isset($_GET['prsm']) ? $product['login'] : ''; ?>"></td>
        <td>Почта:</td>
        <td><input type="mail" name="email" value="<?= isset($_GET['prsm']) ? $product['email'] : ''; ?>"></td>
        </tr>
        <td>Пол:</td>
        <td><input type="text" name="gender" value="<?= isset($_GET['prsm']) ? $product['gender'] : ''; ?>"></td>
        <td>Дата рождения:</td>
        <td><input type="date" name="dateborn" value="<?= isset($_GET['prsm']) ? $product['dateborn'] : ''; ?>"></td>
        <td>Пароль:</td>
        <td><input size="30" type="text" name="password" value="<?= isset($_GET['prsm']) ? $product['password'] : ''; ?>"></td>
        </tr>
    </table>
  </form>

  <form action="" method="post">
    <b>Измененить/добвить</b>
    <table>
      <tr>
        <tr>
        <td>Имя:</td>
        <td><input type="text" name="name" value="<?= isset($_GET['red']) ? $product['name'] : ''; ?>"></td>
        <td>Фамилия:</td>
        <td><input type="text" name="surname" value="<?= isset($_GET['red']) ? $product['surname'] : ''; ?>"></td>
        <td>Логин:</td>
        <td><input type="text" name="login" value="<?= isset($_GET['red']) ? $product['login'] : ''; ?>"></td>
        <td>Почта:</td>
        <td><input type="mail" name="email" value="<?= isset($_GET['red']) ? $product['email'] : ''; ?>"></td>
        </tr>
        <td>Пол:</td>
        <td><input type="text" name="gender" value="<?= isset($_GET['red']) ? $product['gender'] : ''; ?>"></td>
        <td>Дата рождения:</td>
        <td><input type="date" name="dateborn" value="<?= isset($_GET['red']) ? $product['dateborn'] : ''; ?>"></td>
        <td>Пароль:</td>
        <td><input size="30" type="text" name="password" value="<?= isset($_GET['red']) ? $product['password'] : ''; ?>"></td>
        </tr>
        <tr>
        <td><input type="submit" value="сохранить"></td>
      </tr>
    </table>
  </form>

  <table border='1'>
    <tr>
      <td>Ид-тор</td>
      <td>Имя</td>
      <td>Фамилия</td>
      <td>Логин</td>
      <td>Почта</td>
      <td>Пол</td>
      <td>Дата рождения</td>
      <td>Пароль</td>
      <td>Удаление</td>
      <td>Редактирование</td>
      <td>Просмотр</td>
    </tr>
    <?php
      $sql = mysqli_query($link, 'SELECT `ID`, `name`, `surname`, `login`, `email`, `gender`, `dateborn`, `password` FROM `users`');
      while ($result = mysqli_fetch_array($sql)) {
      	echo '<tr>' .
             "<td>{$result['ID']}</td>" .
             "<td>{$result['name']}</td>" .
             "<td>{$result['surname']}</td>" .
             "<td>{$result['login']}</td>" .
             "<td>{$result['email']}</td>" .
             "<td>{$result['gender']}</td>" .
             "<td>{$result['dateborn']}</td>" .
             "<td>{$result['password']}</td>" .
             "<td><a href='?del={$result['ID']}'>Удалить</a></td>" .
             "<td><a href='?red={$result['ID']}'>Изменить</a></td>" .
             "<td><a href='?prsm={$result['ID']}'>Просмотр</a></td>" .
             '</tr>';
      }
    ?>
  </table>
  <p><a href="?add=new">Добавить нового пользователя</a></p>

  <?php

	$query = "SELECT * FROM users ORDER BY id DESC";  
 	$result1 = mysqli_query($link, $query);
?>

<br />            
           <div class="container" style="width:100%;" align="center">  
 
                <div class="table-responsive" id="employee_table">  
                     <table class="table table-bordered">  
                          <tr>  
                               <th><a class="column_sort" id="id" data-order="desc" href="#">Ид-тор</a></th>  
                               <th><a class="column_sort" id="name" data-order="desc" href="#">Имя</a></th>  
                               <th><a class="column_sort" id="surname" data-order="desc" href="#">Фамилия</a></th>  
                               <th><a class="column_sort" id="login" data-order="desc" href="#">Логин</a></th>  
                               <th><a class="column_sort" id="email" data-order="desc" href="#">Почта</a></th>  
                               <th><a class="column_sort" id="gender" data-order="desc" href="#">Пол</a></th>  
                               <th><a class="column_sort" id="dateborn" data-order="desc" href="#">Дата рождения</a></th>  
                               <th><a class="column_sort" id="password" data-order="desc" href="#">пароль</a></th>  
                          </tr>  
                          <?php  
                          while($row = mysqli_fetch_array($result1))  
                          {  
                          ?>  
                          <tr>  
                               <td><?php echo $row["id"]; ?></td>  
                               <td><?php echo $row["name"]; ?></td>  
                               <td><?php echo $row["surname"]; ?></td>  
                               <td><?php echo $row["login"]; ?></td>  
                               <td><?php echo $row["email"]; ?></td>  
                               <td><?php echo $row["gender"]; ?></td>  
                               <td><?php echo $row["dateborn"]; ?></td>  
                               <td><?php echo $row["password"]; ?></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
           <br />  
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      $(document).on('click', '.column_sort', function(){  
           var column_name = $(this).attr("id");  
           var order = $(this).data("order");  
           var arrow = '';  
           //glyphicon glyphicon-arrow-up  
           //glyphicon glyphicon-arrow-down  
           if(order == 'desc')  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-down"></span>';  
           }  
           else  
           {  
                arrow = '&nbsp;<span class="glyphicon glyphicon-arrow-up"></span>';  
           }  
           $.ajax({  
                url:"sort.php",  
                method:"POST",  
                data:{column_name:column_name, order:order},  
                success:function(data)  
                {  
                     $('#employee_table').html(data);  
                     $('#'+column_name+'').append(arrow);  
                }  
           })  
      });  
 });  
 </script>  

<?php else : ?>
<b style="color: red;">Вы не авторизованы!</b><br/>
<a href="/login.php">Авторизация</a> </br>
<a href="/signup.php">Регистрация</a>
<?php endif; ?>
